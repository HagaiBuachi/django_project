from django.contrib import admin
from .models import Play, Review
admin.site.register(Play)
admin.site.register(Review)





